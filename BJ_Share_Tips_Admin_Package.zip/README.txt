BJ'S SHARE TIPS — NETLIFY ADMIN TRACKER

IMPORTANT: This project needs a Netlify build so its serverless function and Netlify Blobs backend are deployed. Do not deploy only the public folder using a static-only manual upload.

RECOMMENDED SETUP (KEEP YOUR EXISTING NETLIFY SITE)
1. Extract this ZIP on your computer.
2. Create a new private GitHub repository and upload ALL extracted contents, including:
   - public/index.html
   - public/logo.jpg
   - netlify/functions/api.mjs
   - netlify.toml
   - package.json
3. In Netlify, open your EXISTING site jhunjhunwalatips.netlify.app.
4. Go to Project configuration > Build & deploy > Continuous deployment > Link repository (wording may vary).
5. Connect the GitHub repository you created.
6. Set Build command: leave blank (or use npm install if Netlify requests a build command).
   Set Publish directory: public
   Functions directory: netlify/functions
   netlify.toml already declares these settings.
7. Go to Project configuration > Environment variables and add:
   ADMIN_PASSWORD = a strong, unique password you choose
   SESSION_SECRET = a separate random secret of at least 32 characters
8. Trigger a new production deploy and wait for it to finish.

ADMIN
Open the live site, click Admin, and sign in using ADMIN_PASSWORD.
Calls are stored in Netlify Blobs. Only authenticated admin sessions can add/edit/delete calls. Sessions expire after 8 hours.

SECURITY / OPERATIONS
- Never put secrets in public files, GitHub, screenshots, or chat.
- No broker account-opening, payment, or subscription section.
- Prices/CMP are manual; no live NSE price feed is connected.
- The new tracker starts empty. Add only verified calls.
- Confirm the site deploy is successful before sharing it publicly.
